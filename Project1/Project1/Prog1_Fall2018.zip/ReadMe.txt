This zip file contains the following files:

ReadMe.txt - The file you are now reading.

Prog1.txt - This is actually a demonstration executable file of program 1.  To run
	the program change the ".txt" extension to ".exe".  Double click the .exe
	file to run the program.

SprintReport_P1.docx - Scrum report for sprints 1 and 2 for this assignment.  Fill
	this in and return it with your source code.